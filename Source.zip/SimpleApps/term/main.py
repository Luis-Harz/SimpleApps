test = 0
while True:
   if test < 10000000:
      test += 1
   else:
      print("Reached!")
      break
