#!/bin/bash
cd /opt/simpleapps
./SimpleApps "$@"
