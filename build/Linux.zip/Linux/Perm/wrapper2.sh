#!/bin/bash
exec /opt/simpleapps/Terminal -e simpleapps
